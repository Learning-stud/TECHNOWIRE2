from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import csv
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

url = 'https://inc42.com/buzz/from-zepto-to-bira-91-indian-startups-raised-800-mn-this-week/'
driver.get(url)

SCROLL_PAUSE_TIME = 2.0

browser = driver.execute_script("return document.body.scrollHeight")

while True:
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    time.sleep(SCROLL_PAUSE_TIME)

    height = driver.execute_script("return document.body.scrollHeight")
    if height == browser:
        break
    browser = height

try:
    xpath = '//div[@class="funding-table-wrapper"]/table'
    table = WebDriverWait(driver, 20).until(
        EC.visibility_of_element_located((By.XPATH, xpath))
    )
except TimeoutException:
    print("Timeout waiting for table to load")
    driver.quit()
    exit()

rows = table.find_elements(By.TAG_NAME, 'tr')

data = []
for row in rows:
    coloumn = row.find_elements(By.TAG_NAME, 'td')
    coloumn = [col.text.strip() for col in coloumn]
    data.append(coloumn)

csv_file = 'funding_data.csv'
with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
    written = csv.writer(csvfile)
    written.writerows(data)

print(f"Data saved to {csv_file}")

driver.quit()







